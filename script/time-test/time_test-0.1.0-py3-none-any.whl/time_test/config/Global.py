class Global:
    LOG_ENABLE = True
