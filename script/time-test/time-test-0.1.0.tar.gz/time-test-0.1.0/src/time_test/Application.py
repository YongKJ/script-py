from .applet.time_test.TimeTest import TimeTest


class Application:

    @staticmethod
    def run():
        TimeTest.run()
