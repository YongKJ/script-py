# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['time_test',
 'time_test.applet',
 'time_test.applet.time_test',
 'time_test.config',
 'time_test.pojo',
 'time_test.pojo.dto',
 'time_test.util']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0']

entry_points = \
{'console_scripts': ['time-test = time_test.Application:Application.run']}

setup_kwargs = {
    'name': 'time-test',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'dengxiaojun',
    'author_email': 'dxj1718874198@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
