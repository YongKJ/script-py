class Modules:
    yaml = "PyYAML"
