from .applet.demo.Demo import Demo


class Application:

    @staticmethod
    def run():
        Demo.run()
