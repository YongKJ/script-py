# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['demo',
 'demo.applet',
 'demo.applet.demo',
 'demo.config',
 'demo.deploy',
 'demo.deploy.pojo',
 'demo.deploy.pojo.dto',
 'demo.deploy.pojo.po',
 'demo.pojo',
 'demo.pojo.dto',
 'demo.pojo.po',
 'demo.util']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0']

entry_points = \
{'console_scripts': ['demo = demo.Application:Application.run']}

setup_kwargs = {
    'name': 'demo',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'dengxiaojun',
    'author_email': 'dxj1718874198@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
