from .applet.visualized_analysis.VisualizedAnalysis import VisualizedAnalysis


class Application:

    @staticmethod
    def run():
        VisualizedAnalysis.run()
