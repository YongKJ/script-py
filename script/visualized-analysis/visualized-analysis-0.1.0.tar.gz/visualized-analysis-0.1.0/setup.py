# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['visualized_analysis',
 'visualized_analysis.applet',
 'visualized_analysis.applet.visualized_analysis',
 'visualized_analysis.util']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0', 'pandas==1.1.5', 'plotly>=5.15.0,<6.0.0', 'xlrd==1.1.0']

entry_points = \
{'console_scripts': ['visualized-analysis = '
                     'visualized_analysis.Application:Application.run']}

setup_kwargs = {
    'name': 'visualized-analysis',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'dengxiaojun',
    'author_email': 'dxj1718874198@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6.1,<4.0.0',
}


setup(**setup_kwargs)
